#include "Math.h"
#include "Control.h"

int main(){
    srand(time(NULL));
    mainMenu();

    return 0;
}