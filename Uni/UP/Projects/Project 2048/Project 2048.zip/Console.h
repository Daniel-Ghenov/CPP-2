#pragma once

void clearConsole();
void printNum(int** field, int i, int j);
void drawField(int** field, int fieldSize);