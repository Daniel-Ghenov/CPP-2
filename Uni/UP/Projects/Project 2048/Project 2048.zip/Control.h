#pragma once

void mainMenu();
void turnControl(int** field, int* randomWeight, int fieldSize, int& turnCount, int& score);
void controlGame();
