const int MAX_USER_INPUT = 101;
const int numWidth = 7;
const int MAX_POWER_TO_SPAWN = 3;
const int LINE_START = -1;
const int LEADERBOARD_LENGTH = 5;
const int MAX_FILENAME_LENGTH = 23;