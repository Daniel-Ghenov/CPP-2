package bg.sofia.uni.fmi.mjt.csvprocessor;

import org.junit.jupiter.api.Test;

public class CsvProcessorTest {

    @Test
    void testReadCsv() {

    }
}
