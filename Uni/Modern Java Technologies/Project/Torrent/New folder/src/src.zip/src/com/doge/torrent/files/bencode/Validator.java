package com.doge.torrent.files.bencode;

public interface Validator {

	boolean validate(char c);

}
